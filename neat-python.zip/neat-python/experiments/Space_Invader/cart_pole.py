'''
General settings and implementation of the single-pole cart system dynamics.
'''

from math import floor
import random


class CartPole(object):
	def __init__(self, w = 5, h = 5, x = 2, y = 0):
		self.w = w
		self.h = h
		self.x = x
		self.y = y
		self.asteroids = []
		self.score = 0
		self.over = False
		self.run = 0
		random.seed(self.run)

	def step(self,input):
		if(self.over == True):
			return 0
		self.score = self.score + 1;
		#up, down, left, right
		if(input[0] > .5):
			self.y += 1
		if(input[1] > .5):
			self.y -= 1
		if(input[2] > .5):
			self.x -= 1
		if(input[3] > .5):
			self.x += 1
		if(self.y >= self.h or self.y < 0 or self.x >= self.w or self.x < 0):
			self.over = True
		if( [self.x,self.y] in self.asteroids):
			self.over = True
		newAsteroid = []
		for ast in self.asteroids:
			ast[1] -= 1
			if(ast[1] == self.y and ast[0] == self.x):
				self.over = True
			if(ast[1] >= 0):
				newAsteroid.append(ast)
		self.asteroids = newAsteroid
		if(len(self.asteroids) <= (self.w*self.h)*0.3):
			if(random.uniform(0,1) < .5):
				newAst = [floor(random.uniform(0,self.w)),self.h-1]
				if(newAst[0] >= 0 or newAst[0] < self.w):
					self.asteroids.append(newAst)

		if(self.over):
			return 0
		return 1

	def get_output(self):
		out = []
		for i in range(0,self.w):
			for j in range(0,self.h):
				if([i,j] in self.asteroids):
					out.append(1)
					continue
				if(i == self.x and j == self.y):
					out.append(-1)
					continue
				out.append(0)
		return out
	def get_score(self):
		return self.score

	def printBoard(self):
		print("_________________________\n")
		print("Score : " + str(self.score))
		for j in range(0,self.w):
			out = ""
			for i in range(0,self.h):
				if([i,j] in self.asteroids):
					out+="A"
					continue
				if(i == self.x and j == self.y):
					out+="P"
					continue
				out+="-"
			print(out + "\n")
		print("_________________________\n")

	def reset(self):
		self.x = 2
		self.y = 0
		self.asteroids = []
		self.score = 0
		self.over = False
		self.run = (self.run + 15) % 15*10
		random.seed(self.run)
