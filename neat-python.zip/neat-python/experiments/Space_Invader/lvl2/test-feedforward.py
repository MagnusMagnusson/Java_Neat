"""
Test the performance of the best genome produced by evolve-feedforward.py.
"""

from __future__ import print_function

import os
import pickle

from cart_pole import CartPole

import neat
from neat import nn

# load the winner
with open('winner-feedforward', 'rb') as f:
    c = pickle.load(f)

print('Loaded genome:')
print(c)

# Load the config file, which is assumed to live in
# the same directory as this script.
local_dir = os.path.dirname(__file__)
config_path = os.path.join(local_dir, 'config-feedforward')
config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                     neat.DefaultSpeciesSet, neat.DefaultStagnation,
                     config_path)

net = neat.nn.FeedForwardNetwork.create(c, config)
sim = CartPole()

print()
print("Initial conditions:")
print("        x = {0:.4f}".format(sim.x))
print("        y = {0:.4f}".format(sim.y))
print("    w = {0:.4f}".format(sim.w))
print("    h = {0:.4f}".format(sim.h))
print()

# Run the given simulation for up to 120 seconds.
while sim.score <= 500:
	inputs = sim.get_output()
	#print(inputs)
	action = net.activate(inputs)

	# Apply action to the simulated cart-pole
	dead = sim.step(action)
	if(dead == 0):
		break
	sim.printBoard()


print('AI recieved {0:.1f} of 500 points'.format(sim.get_score()))
