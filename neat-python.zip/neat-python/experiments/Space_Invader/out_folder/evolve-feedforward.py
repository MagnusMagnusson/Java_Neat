"""
Single-pole balancing experiment using a feed-forward neural network.
"""

from __future__ import print_function

import os
import pickle

import cart_pole

import neat
import visualize

runs_per_net = 5
simulation_seconds = 500.0

def avg(list):
	tot = 1.0
	num = 0.0
	for i in list:
		tot += i
		num += 1
	return tot/num
# Use the NN network phenotype and the discrete actuator force function.
def eval_genome(genome, config):
    net = neat.nn.FeedForwardNetwork.create(genome, config)

    fitnesses = []

    for runs in range(runs_per_net):
        sim = cart_pole.CartPole()

        # Run the given simulation for up to num_steps time steps.
        fitness = 0.0
        while sim.get_score() < simulation_seconds:
            inputs = sim.get_output()
            #print(inputs)
            action = net.activate(inputs)

            # Apply action to the simulated cart-pole
            dead = sim.step(action)
            if(dead == 0):
                break
            fitness = sim.get_score()

        fitnesses.append(fitness)
        sim.reset()

    # The genome's fitness is its worst performance across all runs.
	mm = min(fitnesses)
    if(mm >= 499):
        sim.reset()
        while sim.get_score() < simulation_seconds:
            sim.printBoard()
            inputs = sim.get_output()
            action = net.activate(inputs)
            dead = sim.step(action)
            if(dead == 0):
				sim.printBoard()
				break
		
    return avg(fitnesses)


def eval_genomes(genomes, config):
    for genome_id, genome in genomes:
        genome.fitness = eval_genome(genome, config)


def run():
    # Load the config file, which is assumed to live in
    # the same directory as this script.
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, 'config-feedforward')
    config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                         neat.DefaultSpeciesSet, neat.DefaultStagnation,
                         config_path)

    pop = neat.Population(config)
    stats = neat.StatisticsReporter()
    pop.add_reporter(stats)
    pop.add_reporter(neat.StdOutReporter(True))

    pe = neat.ParallelEvaluator(4, eval_genome)
    winner = pop.run(pe.evaluate,1100)

    # Save the winner.
    with open('winner-feedforward', 'wb') as f:
        pickle.dump(winner, f)
		
    print(winner)


    visualize.plot_stats(stats, ylog=False, view=True, filename="feedforward-fitness.svg")
    visualize.plot_species(stats, view=False, filename="feedforward-speciation.svg")
	
	
    net = neat.nn.FeedForwardNetwork.create(genome, config)

    fitnesses = []

    for runs in range(runs_per_net):
        sim = cart_pole.CartPole()

        # Run the given simulation for up to num_steps time steps.
        fitness = 0.0
        while sim.get_score() < simulation_seconds:
            inputs = sim.get_output()
            #print(inputs)
            action = net.activate(inputs)

            # Apply action to the simulated cart-pole
            dead = sim.step(action)
            if(dead == 0):
                break
            fitness = sim.get_score()

        fitnesses.append(fitness)
        sim.reset()
		

if __name__ == '__main__':
    run()
