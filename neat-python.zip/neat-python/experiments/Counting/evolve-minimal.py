"""
2-input XOR example -- this is most likely the simplest possible example.
"""

from __future__ import print_function
import neat

def get_input_list(bl,list,size):
    if(size == 0):
        bl.append(list)
        return
    l1 = list[:]
    l2 = list[:]
    l1.append(0)
    l2.append(1)
    get_input_list(bl,l1,size-1)
    get_input_list(bl,l2,size-1)
  
xinput = []
get_input_list(xinput,[],5)
xoutput = []
for i in xinput:
	s = 0
	for j in i :
		s += j
	xoutput.append([(s & 4) / 4,(s & 2) / 2,s & 1])

def eval_genomes(genomes, config):
    for genome_id, genome in genomes:
        genome.fitness = 0
        net = neat.nn.FeedForwardNetwork.create(genome, config)
        for xi, xo in zip(xinput, xoutput):
            output = net.activate(xi)
            genome.fitness -= ((output[0] - xo[0]) ** 8) + ((output[1] - xo[1]) ** 4) + ((output[2] - xo[2]) ** 2)


# Load configuration.
config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                     neat.DefaultSpeciesSet, neat.DefaultStagnation,
                     'config-feedforward')

# Create the population, which is the top-level object for a NEAT run.
p = neat.Population(config)

# Add a stdout reporter to show progress in the terminal.
p.add_reporter(neat.StdOutReporter(False))

# Run until a solution is found.
winner = p.run(eval_genomes,10000)

# Display the winning genome.
print('\nBest genome:\n{!s}'.format(winner))

# Show output of the most fit genome against training data.
print('\nOutput:')
winner_net = neat.nn.FeedForwardNetwork.create(winner, config)
for xi, xo in zip(xinput, xoutput):
    output = winner_net.activate(xi)
    print("  input {!r}, expected output {!r}, got {!r}".format(xi, xo, output))
